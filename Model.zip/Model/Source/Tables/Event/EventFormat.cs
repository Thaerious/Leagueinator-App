﻿namespace Leagueinator.Model.Tables {
    public enum EventFormat { AssignedLadder }
}
