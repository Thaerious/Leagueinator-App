﻿namespace Leagueinator.Model.Tables {
    public enum MatchFormat { VS1, VS2, VS3, VS4, A4321 };
}
